package com.mohammadbesharat.atlasmeat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtlasmeatApplicationTests {

	@Test
	void contextLoads() {
	}

}
